def force(a,b,c,d,e,f,g):
    x = a
    y = b
    z = c
    k = d
    m = e
    n = f
    return {x,y,z,k,m,n}



force.x
