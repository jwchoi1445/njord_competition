#!/usr/bin/env python2

import rospy
from ros_clients.msg import GeneralizedForce
from rospy.topics import Subscriber
from std_msgs.msg import String
import grpc
import sys



def values():
    # print '(w for forward, a for left, s for reverse, d for right, k for turning left, 1for turning right and . for exit)' 
    s = raw_input(':- ')
    
    if s[0] == 'w':
        x = 150.0
        y = 0
        z = 0
        k = 0
        m = 0
        n = 0
    elif s[0] == 's':
        x = -150.0
        y = 0
        z = 0
        k = 0
        m = 0
        n = 0
    elif s[0] == 'd':
        x = 0.0
        y = 0.0
        z = 0.0
        k = 0.0
        m = 0.0
        n = 100.0
    elif s[0] == 'a':
        x = 0.0
        y = 0.0
        z = 0.0
        k = 0.0
        m = 0.0
        n = -100.0
    elif s[0] == 'k':
        x = 0.0
        y = 0.0
        z = 0.0
        k = 0.0
        m = 0.0
        n = 100.0
    elif s[0] == 'l':
        x = 0.0
        y = 0.0
        z = 0.0
        k = 0.0
        m = 0.0
        n = -100.0
    elif s[0] == '.':
        x = 0.0
        y = 0.0
        z = 0.0
        k = 0.0
        m = 0.0
        n = 0.0
    else:
        x = 0.0
        y = 0.0
        z = 0.0
        k = 0.0
        m = 0.0
        n = 0.0
        rospy.loginfo('Wrong command ')

    force = [x,y,z,k,m,n]
    return  force




# pub = rospy.Publisher('force_control', GeneralizedForce, queue_size=10)
# rospy.init_node('control_node',anonymous=True)
# rospy.loginfo('----------------test_node start------------')
# rate = rospy.Rate(10)


# while not rospy.is_shutdown():
#     counter = int()
#     str_info = 'current count: %d' %counter
#     rospy.loginfo(str_info)

#     pub.publish(*values())
#     counter += 1
#     rate.sleep()


def keyboard():

    pub = rospy.Publisher('force_control', GeneralizedForce, queue_size=10)
    rospy.init_node('control_node',anonymous=True)
    rospy.loginfo('----------------test_node start------------')
    rate = rospy.Rate(10)
    counter = int()

    while not rospy.is_shutdown():
        counter +=1
        str_info = 'current count: %d' %counter
        rospy.loginfo(str_info)

        pub.publish(*values())
        
        continue
        rate.sleep()

if __name__ == '__main__':
    try :
        
        keyboard()
    except rospy.ROSInterruptException:
        pass

